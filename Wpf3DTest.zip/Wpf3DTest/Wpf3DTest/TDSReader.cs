﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Media3D;
using System.IO;

namespace Wpf3DTest
{
    class Chunk
    {
        public ushort ID;  // 2 bytes
        public uint size;  // 4 bytes
        public uint bytesRead;
    }

    class Face
    {
        public ushort firstPoint;
        public ushort secondPoint;
        public ushort thirdPoint;
        public ushort flag;

        public Face(ushort f, ushort s, ushort t, ushort fl)
        {
            firstPoint = f;
            secondPoint = s;
            thirdPoint = t;
            flag = fl;
        }
    }

    class TDSReader
    {
        private List<Point3D> verticesList = new List<Point3D>();
        private List<Face> facesList = new List<Face>();
        private string fileName;

        public TDSReader(string name)
        {
            fileName = name;
        }

        public void ReadFile(string name)
        {
            fileName = name;
            ReadFile();
        }

        public List<Point3D> GetVertices()
        {
            return verticesList;
        }

        public List<Face> GetFaces()
        {
            return facesList;
        }

        public void ReadFile()
        {
            using (BinaryReader file = new BinaryReader(File.Open(fileName, FileMode.Open)))
            {
                Chunk chunk = new Chunk();
                uint bytesRead = 0;

                ReadChunkHeader(file, ref chunk);
                if (chunk.ID != 0x4d4d)
                    return;

                while (chunk.bytesRead < chunk.size)
                {
                    Chunk tempChunk = new Chunk();
                    ReadChunkHeader(file, ref tempChunk);
                    switch (tempChunk.ID)
                    {
                        case 0x3d3d:
                            ReadEDIT3DS(file, ref tempChunk);
                            bytesRead = tempChunk.size;
                            break;
                        default:
                            SkipChunk(file, ref tempChunk);
                            bytesRead = tempChunk.size;
                            break;
                    }
                    chunk.bytesRead += bytesRead;
                }

            }
        }

        private void ReadChunkHeader(BinaryReader file, ref Chunk chunk)
        {
            chunk.ID = file.ReadUInt16();
            chunk.size = file.ReadUInt32();
            chunk.bytesRead = sizeof(UInt16) + sizeof(UInt32);
        }

        private void SkipChunk(BinaryReader file, ref Chunk chunk)
        {
            file.ReadBytes((int)(chunk.size - chunk.bytesRead));
        }

        private void ReadEDIT3DS(BinaryReader file, ref Chunk chunk)
        {
            while (chunk.bytesRead < chunk.size)
            {
                Chunk tempChunk = new Chunk();
                ReadChunkHeader(file, ref tempChunk);
                switch (tempChunk.ID)
                {
                    case 0x4000:
                        Read3DObject(file, ref tempChunk);
                        break;
                    default:
                        SkipChunk(file, ref tempChunk);
                        break;
                }
                chunk.bytesRead += tempChunk.size;
            }
        }

        private void Read3DObject(BinaryReader file, ref Chunk chunk)
        {
            uint objectNameSize = GetString(file);
            chunk.bytesRead += objectNameSize;

            while (chunk.bytesRead < chunk.size)
            {
                Chunk tempChunk = new Chunk();
                ReadChunkHeader(file, ref tempChunk);

                switch (tempChunk.ID)
                {
                    case 0x4100:
                        LoadMesh(file, ref tempChunk);
                        break;
                    default:
                        SkipChunk(file, ref tempChunk);
                        break;
                }
                chunk.bytesRead += tempChunk.size;
            }

        }

        private void LoadMesh(BinaryReader file, ref Chunk chunk)
        {
            while (chunk.bytesRead < chunk.size)
            {
                Chunk tempChunk = new Chunk();
                ReadChunkHeader(file, ref tempChunk);

                switch (tempChunk.ID)
                {
                    case 0x4110:
                        ReadVertices(file, ref tempChunk);
                        break;
                    case 0x4120:
                        ReadFaces(file, ref tempChunk);
                        break;
                    default:
                        SkipChunk(file, ref tempChunk);
                        break;
                }
                chunk.bytesRead += tempChunk.size;
            }
        }

        private void ReadVertices(BinaryReader file, ref Chunk chunk)
        {
            uint numberVertices = 0;
            numberVertices = file.ReadUInt16();
            chunk.bytesRead += sizeof(UInt16);

            uint verticesRead = 0;
            while (verticesRead < numberVertices)
            {
                verticesList.Add(new Point3D(file.ReadSingle(), file.ReadSingle(), file.ReadSingle()));
                chunk.bytesRead += 3 * sizeof(float);
                verticesRead += 1;
            }
            SkipChunk(file, ref chunk);
        }

        private void ReadFaces(BinaryReader file, ref Chunk chunk)
        {
            uint NumberFaces = 0;
            NumberFaces = file.ReadUInt16();
            chunk.bytesRead += sizeof(UInt16);

            uint facesRead = 0;
            while (facesRead < NumberFaces)
            {
                facesList.Add(new Face(file.ReadUInt16(), file.ReadUInt16(), file.ReadUInt16(), file.ReadUInt16()));
                chunk.bytesRead += 4 * sizeof(UInt16);
                facesRead += 1;
            }

            SkipChunk(file, ref chunk);
        }

        private uint GetString(BinaryReader file)
        {
            char charRead;
            string name = "";
            do
            {
                charRead = file.ReadChar();
                name = name.Insert(name.Length, char.ToString(charRead));
            } while (charRead != 0);
            return (uint)name.Length;
        }
    }
}
